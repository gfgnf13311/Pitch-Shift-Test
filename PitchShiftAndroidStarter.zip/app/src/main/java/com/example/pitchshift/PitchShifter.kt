package com.example.pitchshift

import kotlin.math.pow

/**
 * JNI interface. The current native implementation is a build/linkage placeholder.
 * Replace it with the Rubber Band Library API for quality, duration-preserving pitch shift.
 */
class PitchShifter(sampleRate: Int, channels: Int) : AutoCloseable {
    private val handle = nativeCreate(sampleRate, channels)

    fun process(input: FloatArray, output: FloatArray, semitones: Float) {
        require(input.size == output.size)
        require(semitones in -12f..12f)
        val ratio = 2.0.pow(semitones / 12.0).toFloat()
        nativeProcess(handle, input, output, ratio)
    }

    override fun close() = nativeDestroy(handle)

    private external fun nativeCreate(sampleRate: Int, channels: Int): Long
    private external fun nativeProcess(handle: Long, input: FloatArray, output: FloatArray, pitchRatio: Float)
    private external fun nativeDestroy(handle: Long)

    companion object { init { System.loadLibrary("pitchshift") } }
}
