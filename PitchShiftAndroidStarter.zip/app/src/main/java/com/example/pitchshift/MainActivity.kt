package com.example.pitchshift

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var selectedVideo: Uri? = null
    private var semitones = 0
    private lateinit var status: TextView
    private lateinit var pitchLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "PitchShift Video"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Select a video, choose a pitch shift, then export an MP4."
            textSize = 15f
            setPadding(0, 18, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "Choose video"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "video/*"
                }
                startActivityForResult(intent, PICK_VIDEO)
            }
        }, match())
        pitchLabel = TextView(this).apply { text = "Pitch: 0 semitones"; textSize = 18f; setPadding(0, 28, 0, 8) }
        root.addView(pitchLabel)
        root.addView(SeekBar(this).apply {
            max = 24
            progress = 12
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    semitones = progress - 12
                    pitchLabel.text = "Pitch: ${if (semitones > 0) "+" else ""}$semitones semitones"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, match())
        root.addView(Button(this).apply {
            text = "Export MP4"
            setOnClickListener {
                if (selectedVideo == null) {
                    Toast.makeText(this@MainActivity, "Choose a video first.", Toast.LENGTH_SHORT).show()
                } else {
                    // Export pipeline is intentionally guarded until the Rubber Band backend
                    // and a media mux/transcode implementation are integrated.
                    status.text = "Video selected. Native Rubber Band processing and MP4 muxing are scaffolded but not yet wired. See README."
                }
            }
        }, match())
        status = TextView(this).apply {
            text = "Ready. This starter builds an APK; see README for the remaining media pipeline integration."
            textSize = 14f
            setPadding(0, 24, 0, 0)
        }
        root.addView(status)
        setContentView(root)
    }

    @Deprecated("Legacy activity result callback used for broad API compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK) {
            selectedVideo = data?.data
            selectedVideo?.let { uri ->
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                status.text = "Selected: ${uri.lastPathSegment ?: "video"}"
            }
        }
    }

    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = 12
    }

    companion object { private const val PICK_VIDEO = 1001 }
}
